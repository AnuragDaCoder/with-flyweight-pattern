﻿using FlyweightPattern;

namespace WithoutFlyweightPattern
{
    public class OrderItem
    {
        //step1: comment 
        //public string Name { get; set; }
        //public string Description { get; set; }
        //public ProductType Type { get; set; }
        //public double Price { get; set; }

        //step2..
        //public Product Product { get; set; }
        //public string SerialNumber { get; set; }

        //step3..no setter
        //make it completely immutable ...

        public Product Product { get;}
        public string SerialNumber { get;}


        public OrderItem(Product product, string serialNumber)
        {
            //Name = name;
            //Description = description;
            //Type = type;
            //Price = price;
            Product = product;
            SerialNumber = serialNumber;
        }
    }

    public enum ProductType
    {
        GamingConsole,
        Desktops,
        Laptop
    }
}