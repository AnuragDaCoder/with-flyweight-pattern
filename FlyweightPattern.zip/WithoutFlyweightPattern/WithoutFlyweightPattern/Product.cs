﻿
using WithoutFlyweightPattern;

namespace FlyweightPattern
{
    public class Product
    {
        public Product(string name, string description, ProductType type, double price)
        {
            Name = name;
            Description = description;
            Type = type;
            Price = price;
        }

        public string Name { get; set; }
        public string Description { get; set; }
        public ProductType Type { get; set; }
        public double Price { get; set; }
    }
}
