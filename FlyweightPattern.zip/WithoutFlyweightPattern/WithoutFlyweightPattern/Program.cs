﻿using FlyweightPattern;
using System.Text;
using WithoutFlyweightPattern;
class Program
{
    private static int orderCount = 100000;
    static void Main()
    {
         //commen this
        //PSItemFactory pSItemFactory = new PSItemFactory();

        //make this change..
        PSFlyWeightFactory pSFlyWeightFactory = new PSFlyWeightFactory();
        PSItemFactory pSItemFactory = new PSItemFactory(pSFlyWeightFactory);


        List<Order> orders = new List<Order>();
        //from front dropdown you fetch the PS type
        //for example : it is PS5ConsoleEdition
        //1 lakh order count.....
        var orderPsType = PSSeries.PS5ConsoleEdition;
        for (int i = 0; i < orderCount; i++)
        {
            Order order = new Order();
            OrderItem psItem = pSItemFactory.Create(orderPsType, ToBase36((ulong)i));
            order.Add(psItem);
            orders.Add(order);
        }
        Console.ReadKey();
    }

    private static string ToBase36(ulong value)
    {
        const string base36 = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        var sb = new StringBuilder(9);
        do
        {
            sb.Insert(0, base36[(byte)(value % 36)]);
            value /= 36;
        } while (value != 0);

        var paddedString = "ABC" + sb.ToString().PadLeft(6, '0');
        return paddedString;
    }
}