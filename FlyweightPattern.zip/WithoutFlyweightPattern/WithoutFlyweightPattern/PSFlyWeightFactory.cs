﻿using WithoutFlyweightPattern;

namespace FlyweightPattern
{
    public class PSFlyWeightFactory
    {
        private readonly Dictionary<PSSeries, Product> _psSeries;

        public PSFlyWeightFactory()
        {
            _psSeries = new Dictionary<PSSeries, Product>();
        }

        public Product Create(PSSeries series)
        {
            if (!_psSeries.ContainsKey(series))
            {
                switch (series)
                {
                    case PSSeries.PS5ConsoleEdition:
                        _psSeries.Add(series, new Product("PS5 Console Edition",
                        "PS5 Console Edition with a Console free", ProductType.GamingConsole, 54990));
                        break;
                    case PSSeries.PS5DiscEdition:
                        _psSeries.Add(series,new Product("PS5 Disc Edition",
                        "PS5 Disc Edition with a webcam", ProductType.GamingConsole, 54990));
                        break;
                    case PSSeries.PS4:
                        _psSeries.Add(series, new Product("PS4 Console",
                        "PS4 Console old but still the best", ProductType.GamingConsole, 25000));
                        break;
                    case PSSeries.PS3:
                        _psSeries.Add(series, new Product("PS3 Console",
                       "PS3 2006 product", ProductType.GamingConsole, 15000));
                        break;
                    default:
                        break;

                }
            }
            return _psSeries[series];

        }
    }
}
